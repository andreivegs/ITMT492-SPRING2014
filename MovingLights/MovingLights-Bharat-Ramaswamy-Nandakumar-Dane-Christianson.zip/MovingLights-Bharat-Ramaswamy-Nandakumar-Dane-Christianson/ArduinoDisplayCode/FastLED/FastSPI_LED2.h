#warning "This file is going away, please us FastLED.h in the future!"
#include<FastLED.h>
