package ardudomo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

import com.j0n17.led.R;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class Main extends Activity implements OnCheckedChangeListener {

	ToggleButton tgConnect;
	TextView txtLuminosityRoom1;
	TextView txtLuminosityRoom2;
	TextView txtLuminosityBath;
	TextView txtHumidityRoom1;
	TextView txtHumidityRoom2;
	TextView txtHumidityBath;
	TextView txtTempRoom1;
	TextView txtTempRoom2;
	TextView txtTempBath;
	TextView txtPresenceRoom1;
	TextView txtPresenceRoom2;
	TextView txtPresenceBath;
	// private String dataToSend;

	InputStream inStream, inStream2, inStream3;

	// private static final String TAG = "Jon";
	private BluetoothAdapter mBluetoothAdapter = null;
	private Set<BluetoothDevice> pairedDevices = null;
	private BluetoothSocket[] btSockets = null;
	// private OutputStream outStream = null;
	private InputStream[] inStreams = null;
	Handler handler = new Handler();
	Handler handler2 = new Handler();
	Handler handler3 = new Handler();
	byte delimiter = 10;
	boolean stopWorker = false;
	int readBufferPosition = 0;
	byte[] readBuffer = new byte[1024];
	Thread workerThread, workerThread2, workerThread3, workerThread4;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		tgConnect = (ToggleButton) findViewById(R.id.tgConnect);
		txtLuminosityRoom1 = (TextView) findViewById(R.id.txtLuminosityRoom1);
		txtLuminosityRoom2 = (TextView) findViewById(R.id.txtLuminosityRoom2);
		txtLuminosityBath = (TextView) findViewById(R.id.txtLuminosityBath);
		txtHumidityRoom1 = (TextView) findViewById(R.id.txtHumidityRoom1);
		txtHumidityRoom2 = (TextView) findViewById(R.id.txtHumidityRoom2);
		txtHumidityBath = (TextView) findViewById(R.id.txtHumidityBath);
		txtTempRoom1 = (TextView) findViewById(R.id.txtTmpRoom1);
		txtTempRoom2 = (TextView) findViewById(R.id.txtTmpRoom2);
		txtTempBath = (TextView) findViewById(R.id.txtTmpBath);
		txtPresenceRoom1 = (TextView) findViewById(R.id.txtPresenceRoom1);
		txtPresenceRoom2 = (TextView) findViewById(R.id.txtPresenceRoom2);
		txtPresenceBath = (TextView) findViewById(R.id.txtPresenceBath);
		tgConnect.setOnCheckedChangeListener(this);
		CheckBt();
	}

	private void CheckBt() {
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

		if (!mBluetoothAdapter.isEnabled()) {
			Toast.makeText(getApplicationContext(),
					"Bluetooth is not activated !", Toast.LENGTH_LONG).show();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.connect:
			Connect();
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	public void Connect() {
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		pairedDevices = mBluetoothAdapter.getBondedDevices();

		mBluetoothAdapter.cancelDiscovery();
		try {
			int i = 0;
			if (pairedDevices.size() > 0) {
				btSockets = new BluetoothSocket[pairedDevices.size()];
				// Loop through paired devices
				for (BluetoothDevice device : pairedDevices) {
					UUID myUUID = device.getUuids()[0].getUuid();
					btSockets[i] = device
							.createRfcommSocketToServiceRecord(myUUID);
					btSockets[i].connect();
					i++;
				}
			}
		} catch (IOException e) {
			try {
				for (BluetoothSocket sock : btSockets) {
					sock.close();
				}
			} catch (IOException e2) {
			}
		}
	}

	// private void writeData(String data) {
	// try {
	// outStream = btSocket.getOutputStream();
	// } catch (IOException e) {
	// Log.d(TAG, "Bug AVANT l'envoie.", e);
	// }
	//
	// String message = data;
	//
	// byte[] msgBuffer = message.getBytes();
	//
	// try {
	// outStream.write(msgBuffer);
	// } catch (IOException e) {
	// Log.d(TAG, "Bug DURANT l'envoie.", e);
	// }
	// }

	@Override
	protected void onDestroy() {
		super.onDestroy();
		stopWorker = true;
		try {
			for (BluetoothSocket sock : btSockets) {
				sock.close();
			}
		} catch (IOException e) {
		}
	}

	@Override
	public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
		switch (arg0.getId()) {
		case R.id.tgConnect:
			if (arg1) {
				Connect();
			} else {
				if (btSockets[0].isConnected()) {
					try {
						stopWorker = true;
						btSockets[0].close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			;
			// case R.id.tgOnOff:
			// if (arg1) {
			// dataToSend = "a";
			// writeData(dataToSend);
			// } else {
			// dataToSend = "b";
			// writeData(dataToSend);
			// }
			// break;
		}

	}

	public void beginListenForData(View view) {
		stopWorker = false;

		try {
			int i = 0;
			// for (BluetoothSocket sock : btSockets) {
			// inStreams[i] = sock.getInputStream();
			// i++;
			// }
			inStream = btSockets[0].getInputStream();
			inStream2 = btSockets[1].getInputStream();
			inStream3 = btSockets[2].getInputStream();
		} catch (IOException e) {
		}

		Thread workerThread = new Thread(new Runnable() {
			public void run() {
				while (!Thread.currentThread().isInterrupted() && !stopWorker) {
					try {
						int bytesAvailable = inStream.available();
						if (bytesAvailable > 0) {
							byte[] packetBytes = new byte[bytesAvailable];
							inStream.read(packetBytes);
							for (int i = 0; i < bytesAvailable; i++) {
								byte b = packetBytes[i];
								if (b == delimiter) {
									byte[] encodedBytes = new byte[readBufferPosition];
									System.arraycopy(readBuffer, 0,
											encodedBytes, 0,
											encodedBytes.length);
									final String data = new String(
											encodedBytes, "US-ASCII");
									final String[] sensors = data.split(" ");
									readBufferPosition = 0;
									handler.post(new Runnable() {
										public void run() {
											if (sensors.length > 0)
												txtPresenceRoom1
														.setText(sensors[0]);
											if (sensors.length > 1)
												txtHumidityRoom1
														.setText(sensors[1]);
											if (sensors.length > 2)
												txtTempRoom1
														.setText(sensors[2]);
											if (sensors.length > 3)
												txtLuminosityRoom1
														.setText(sensors[3]);
										}
									});
								} else {
									readBuffer[readBufferPosition++] = b;
								}
							}
						}
					} catch (IOException ex) {
						stopWorker = true;
					}
				}
			}
		});
		workerThread.start();

		Thread workerThread2 = new Thread(new Runnable() {
			public void run() {
				while (!Thread.currentThread().isInterrupted() && !stopWorker) {
					try {
						int bytesAvailable = inStream2.available();
						if (bytesAvailable > 0) {
							byte[] packetBytes = new byte[bytesAvailable];
							inStream2.read(packetBytes);
							for (int i = 0; i < bytesAvailable; i++) {
								byte b = packetBytes[i];
								if (b == delimiter) {
									byte[] encodedBytes = new byte[readBufferPosition];
									System.arraycopy(readBuffer, 0,
											encodedBytes, 0,
											encodedBytes.length);
									final String data = new String(
											encodedBytes, "US-ASCII");
									final String[] sensors = data.split(" ");
									readBufferPosition = 0;
									handler2.post(new Runnable() {
										public void run() {
											if (sensors.length > 0)
												txtPresenceRoom2
														.setText(sensors[0]);
											if (sensors.length > 1)
												txtHumidityRoom2
														.setText(sensors[1]);
											if (sensors.length > 2)
												txtTempRoom2
														.setText(sensors[2]);
											if (sensors.length > 3)
												txtLuminosityRoom2
														.setText(sensors[3]);
										}
									});
								} else {
									readBuffer[readBufferPosition++] = b;
								}
							}
						}
					} catch (IOException ex) {
						stopWorker = true;
					}
				}
			}
		});
		workerThread2.start();

		Thread workerThread3 = new Thread(new Runnable() {
			public void run() {
				while (!Thread.currentThread().isInterrupted() && !stopWorker) {
					try {
						int bytesAvailable = inStream3.available();
						if (bytesAvailable > 0) {
							byte[] packetBytes = new byte[bytesAvailable];
							inStream3.read(packetBytes);
							for (int i = 0; i < bytesAvailable; i++) {
								byte b = packetBytes[i];
								if (b == delimiter) {
									byte[] encodedBytes = new byte[readBufferPosition];
									System.arraycopy(readBuffer, 0,
											encodedBytes, 0,
											encodedBytes.length);
									final String data = new String(
											encodedBytes, "US-ASCII");
									final String[] sensors = data.split(" ");
									readBufferPosition = 0;
									handler3.post(new Runnable() {
										public void run() {
											if (sensors.length > 0)
												txtPresenceBath
														.setText(sensors[0]);
											if (sensors.length > 1)
												txtHumidityBath
														.setText(sensors[1]);
											if (sensors.length > 2)
												txtTempBath.setText(sensors[2]);
											if (sensors.length > 3)
												txtLuminosityBath
														.setText(sensors[3]);
										}
									});
								} else {
									readBuffer[readBufferPosition++] = b;
								}
							}
						}
					} catch (IOException ex) {
						stopWorker = true;
					}
				}
			}
		});
		workerThread3.start();
	}

}
