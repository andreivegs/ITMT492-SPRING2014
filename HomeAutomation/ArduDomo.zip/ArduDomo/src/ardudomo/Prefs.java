package ardudomo;

public class Prefs {

}
